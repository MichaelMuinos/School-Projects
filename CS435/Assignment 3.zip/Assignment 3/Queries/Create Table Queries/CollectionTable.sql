CREATE TABLE Collection(
	Name VARCHAR(30) NOT NULL,
    Type VARCHAR(30) NOT NULL,
    Description VARCHAR(512) NOT NULL,
    Address VARCHAR(50) NOT NULL,
    PhoneNumber VARCHAR(30) NOT NULL,
    ContactPersonName VARCHAR(50) NOT NULL,
    PRIMARY KEY(Name)
);