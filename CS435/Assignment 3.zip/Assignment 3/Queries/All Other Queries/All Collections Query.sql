SELECT * FROM Collection;

-- Query all Collections.