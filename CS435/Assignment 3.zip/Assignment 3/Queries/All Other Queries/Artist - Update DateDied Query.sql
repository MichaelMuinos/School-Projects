UPDATE Artist 
	SET DateDied="1519-5-2" 
	WHERE Name="Leonardo da Vinci";
    
    
-- Update the date that the artist has died. Sad day.