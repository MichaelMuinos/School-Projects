SELECT Title, Description, Category, ArtistName, Epoch FROM ArtObject
	WHERE Ownership="borrow";
    

-- Query all Art that identifies as being Borrowed.