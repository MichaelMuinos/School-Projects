SELECT * FROM Artist WHERE MainStyle="modern";
-- SELECT * FROM Artist WHERE MainStyle="abstract";


-- Query an Artist by their main style used.