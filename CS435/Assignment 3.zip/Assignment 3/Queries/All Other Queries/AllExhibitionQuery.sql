SELECT * FROM Exhibition;


-- Query by all ongoing exhibitions.