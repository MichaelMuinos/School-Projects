SELECT * FROM ArtObject WHERE Category="other";
-- SELECT * FROM ArtObject WHERE Category="sculpture";
-- SELECT * FROM ArtObject WHERE Category="painting";
-- SELECT * FROM ArtObject WHERE Category="statue";


-- Query Art by their category.