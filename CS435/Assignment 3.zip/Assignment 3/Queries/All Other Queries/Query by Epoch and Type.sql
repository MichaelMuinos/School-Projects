SELECT * FROM ArtObject WHERE epoch="modern" AND category="painting";
-- SELECT * FROM ArtObject WHERE epoch="ancient" AND category="other";
-- SELECT * FROM ArtObject WHERE epoch="renaissance" AND category="sculpture";


-- Query Art by their epoch and category type.