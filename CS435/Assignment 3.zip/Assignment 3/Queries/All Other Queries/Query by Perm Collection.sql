SELECT Title, Description, Category, ArtistName, Epoch FROM ArtObject
	WHERE Ownership="perm";
    

-- Query all Art that identifies as being part of the Permanent Collection.