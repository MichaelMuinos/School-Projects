SELECT * FROM ArtObject WHERE ArtistName="Vincent van Gogh";
-- SELECT * FROM ArtObject WHERE ArtistName="Leonardo da Vinci";


-- Query an Art object by the Artist name.