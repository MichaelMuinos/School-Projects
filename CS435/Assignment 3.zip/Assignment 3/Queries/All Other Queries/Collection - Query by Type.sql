SELECT * FROM Collection WHERE Type="museum";
-- SELECT * FROM Collection WHERE Type="personal";


-- Query the Collection by the type of collection it is identified as (museum, personal, etc)