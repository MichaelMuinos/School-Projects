SELECT * FROM ArtObject WHERE origin="American";
-- SELECT * FROM ArtObject WHERE origin="Italian";
-- SELECT * FROM ArtObject WHERE origin="Egyptian";


-- Query the Art by the origin of the piece.